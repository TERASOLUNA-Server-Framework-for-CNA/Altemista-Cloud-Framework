
Unit tests for the private utility classes of the module business module.
