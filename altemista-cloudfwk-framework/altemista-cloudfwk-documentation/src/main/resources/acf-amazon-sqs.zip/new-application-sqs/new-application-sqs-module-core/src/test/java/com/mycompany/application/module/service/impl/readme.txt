
Unit tests for the services of module.
