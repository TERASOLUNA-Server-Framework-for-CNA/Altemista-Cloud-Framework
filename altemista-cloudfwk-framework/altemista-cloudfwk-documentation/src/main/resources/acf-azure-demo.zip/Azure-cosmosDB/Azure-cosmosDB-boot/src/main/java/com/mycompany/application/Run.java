package com.mycompany.application;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.mycompany.application.repository.UserRepository;

@Configuration
public class Run {


	@Autowired
	private UserRepository repository;

//	@Override
	public void read() throws Exception {
		// TODO Auto-generated method stub
		// Create a simple date/time ID.
		SimpleDateFormat userId = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		Date currentDate = new Date();
		
		System.out.println("hola");
		// Create a new User class.
		final User testUser = new User(userId.format(currentDate), "Gena", "Soto");
		
		// For this example, remove all of the existing records.
		repository.deleteAll();
		
		// Save the User class to the Azure database.
		repository.save(testUser);
		
		// Retrieve the database record for the User class you just saved by ID.
		final User result = repository.findOne(testUser.getId());
		//final User result = repository.findById(testUser.getId()).get();
		
		// Display the results of the database record retrieval.
		System.out.printf("\n\n%s\n\n",result.toString());
	}
	
}
