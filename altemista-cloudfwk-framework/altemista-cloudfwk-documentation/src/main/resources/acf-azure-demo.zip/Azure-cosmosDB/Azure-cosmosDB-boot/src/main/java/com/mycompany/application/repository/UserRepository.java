package com.mycompany.application.repository;

import com.microsoft.azure.spring.data.documentdb.repository.DocumentDbRepository;
import com.mycompany.application.User;

import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends DocumentDbRepository<User, String> { } 