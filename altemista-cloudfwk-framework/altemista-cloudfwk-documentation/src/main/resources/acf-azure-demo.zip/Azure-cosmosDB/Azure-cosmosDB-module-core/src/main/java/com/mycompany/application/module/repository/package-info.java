/**
 * Private part of the business model of module
 * (i.e.: the model used internally by the module business module, but not externally exposed).
 */
package com.mycompany.application.module.repository;
