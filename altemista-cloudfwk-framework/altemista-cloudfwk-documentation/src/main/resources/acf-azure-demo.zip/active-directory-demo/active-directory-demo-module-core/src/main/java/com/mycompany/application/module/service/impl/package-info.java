/**
 * Implementation of both the exposed and the internal services of module.
 * I.e.: {@code @Service} annotated classes
 */
package com.mycompany.application.module.service.impl;
