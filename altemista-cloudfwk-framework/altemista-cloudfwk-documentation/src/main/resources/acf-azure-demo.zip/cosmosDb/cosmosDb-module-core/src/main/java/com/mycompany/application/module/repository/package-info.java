/**
 * Interfaces of the Spring Data JPA repositories of module.
 */
package com.mycompany.application.module.repository;
