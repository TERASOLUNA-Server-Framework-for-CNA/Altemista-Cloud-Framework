/**
 * Interfaces of the exposed services of ${businessShortId}.
 */
package com.mycompany.application.microservice.service;
