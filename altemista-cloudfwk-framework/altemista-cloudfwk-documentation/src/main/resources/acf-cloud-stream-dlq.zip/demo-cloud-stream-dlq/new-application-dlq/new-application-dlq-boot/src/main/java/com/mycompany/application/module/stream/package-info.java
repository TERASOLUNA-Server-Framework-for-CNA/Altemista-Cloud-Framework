/**
 * ETL support Spring beans for the batch processing of module.
 * (i.e.: {@code ItemReader}, {@code ItemProcessor}, and {@code ItemWriter} {@code @Component}s)
 */
package com.mycompany.application.module.stream;
