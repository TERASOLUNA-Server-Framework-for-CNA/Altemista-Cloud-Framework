
-- T_ORM_EXAMPLE values
insert into T_ORM_EXAMPLE (NAME, DESCRIPTION) values ('I', 'One');
insert into T_ORM_EXAMPLE (NAME, DESCRIPTION) values ('V', 'Five');
insert into T_ORM_EXAMPLE (NAME, DESCRIPTION) values ('X', 'Ten');
