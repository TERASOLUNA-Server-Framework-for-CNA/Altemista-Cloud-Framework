/**
 * Exceptions thrown by the service interfaces of module.
 * Can also include additional exceptions.
 */
package com.mycompany.application.module.exception;
