/**
 * Interfaces of the internal services of module.
 */
package com.mycompany.application.module.service;
