package com.mycompany.application.microservice;

import org.terasoluna.plus.config.boot.TerasolunaPlusApplicationBuilder;
import org.terasoluna.plus.config.microservice.TerasolunaPlusMicroserviceBuilder;
import org.terasoluna.plus.config.microservice.TerasolunaPlusMicroservice;

@TerasolunaPlusMicroservice
public class MicroserviceApplication extends TerasolunaPlusMicroserviceBuilder {

    public static void main(String[] args) {
        configureApplication(new TerasolunaPlusApplicationBuilder(), MicroserviceApplication.class).run(args);
    }
	
}
