/**
 * DTOs
 */
package com.mycompany.application.microservice.domain;
