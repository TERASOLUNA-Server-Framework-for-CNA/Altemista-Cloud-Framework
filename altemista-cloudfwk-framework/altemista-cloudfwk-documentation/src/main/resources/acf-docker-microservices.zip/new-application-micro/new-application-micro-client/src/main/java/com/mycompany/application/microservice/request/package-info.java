/**
 * Request POJOs
 */
package com.mycompany.application.microservice.request;
