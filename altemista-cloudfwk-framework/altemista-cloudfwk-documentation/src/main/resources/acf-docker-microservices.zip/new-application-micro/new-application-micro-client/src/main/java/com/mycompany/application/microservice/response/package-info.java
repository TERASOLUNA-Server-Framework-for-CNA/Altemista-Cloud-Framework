/**
 * Response POJOs
 */
package com.mycompany.application.microservice.response;
