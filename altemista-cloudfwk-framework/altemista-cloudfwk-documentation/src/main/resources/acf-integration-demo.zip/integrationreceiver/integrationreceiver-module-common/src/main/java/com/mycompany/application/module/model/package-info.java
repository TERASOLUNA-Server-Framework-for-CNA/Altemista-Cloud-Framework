/**
 * Business model of module (i.e.: the model actually exposed by the module business module).
 * This model contains the model used by the service interfaces, but can include additional classes as well.
 */
package com.mycompany.application.module.model;
