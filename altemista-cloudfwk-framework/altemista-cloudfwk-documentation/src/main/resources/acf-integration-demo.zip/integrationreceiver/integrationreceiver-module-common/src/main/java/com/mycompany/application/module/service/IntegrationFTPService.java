package com.mycompany.application.module.service;

public interface IntegrationFTPService {
	
	public void sendFile(String filePath);

}
