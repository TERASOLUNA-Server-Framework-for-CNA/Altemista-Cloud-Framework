package com.mycompany.application.module.service;

public interface IntegrationHTTPService {

	public String send(String message);
}
