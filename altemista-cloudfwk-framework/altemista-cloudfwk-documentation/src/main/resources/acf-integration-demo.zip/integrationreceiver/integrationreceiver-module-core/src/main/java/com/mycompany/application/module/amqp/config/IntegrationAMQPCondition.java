package com.mycompany.application.module.amqp.config;

public class IntegrationAMQPCondition {

}
