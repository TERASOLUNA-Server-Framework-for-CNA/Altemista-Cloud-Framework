/**
 * Spring Integration Listener configurations
 */
package com.mycompany.application.module.amqp.config;