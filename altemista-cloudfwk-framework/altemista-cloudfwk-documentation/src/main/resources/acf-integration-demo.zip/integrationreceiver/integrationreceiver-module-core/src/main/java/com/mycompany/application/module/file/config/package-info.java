/**
 * Spring Integration Configurations
 */
package com.mycompany.application.module.file.config;