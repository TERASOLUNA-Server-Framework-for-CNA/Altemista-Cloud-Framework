package com.mycompany.application.module.http.config;

public interface RequestGateway {

	String echo(String request);

}
