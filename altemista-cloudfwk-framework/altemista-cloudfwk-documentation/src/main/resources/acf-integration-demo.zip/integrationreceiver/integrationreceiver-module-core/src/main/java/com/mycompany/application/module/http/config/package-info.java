/**
 * Spring Integration Configurations
 */
package com.mycompany.application.module.http.config;