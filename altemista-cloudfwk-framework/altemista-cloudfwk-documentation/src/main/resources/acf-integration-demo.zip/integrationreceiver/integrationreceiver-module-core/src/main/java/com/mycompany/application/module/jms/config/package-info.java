/**
 * Spring Integration Configurations
 */
package com.mycompany.application.module.jms.config;