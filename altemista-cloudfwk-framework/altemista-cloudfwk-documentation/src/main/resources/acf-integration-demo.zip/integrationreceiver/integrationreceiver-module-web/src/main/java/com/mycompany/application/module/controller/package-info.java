/**
 * Spring MVC controllers of the module business module, served at "/app/*".
 * I.e.: {@code @Conrtoller} annotated classes
 */
package com.mycompany.application.module.controller;
