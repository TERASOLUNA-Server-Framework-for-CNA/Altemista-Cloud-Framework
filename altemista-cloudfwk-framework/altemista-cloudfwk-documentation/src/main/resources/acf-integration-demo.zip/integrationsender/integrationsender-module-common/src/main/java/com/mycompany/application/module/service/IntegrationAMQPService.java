package com.mycompany.application.module.service;

public interface IntegrationAMQPService {
	
	public void sendMessage(String message);

}
