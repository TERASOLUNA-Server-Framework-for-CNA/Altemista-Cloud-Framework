/**
 * Interfaces of the exposed services of module.
 */
package com.mycompany.application.module.service;
