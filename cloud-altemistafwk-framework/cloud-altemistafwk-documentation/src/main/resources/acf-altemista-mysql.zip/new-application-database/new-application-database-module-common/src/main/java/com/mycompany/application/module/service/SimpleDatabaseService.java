package com.mycompany.application.module.service;

import org.springframework.stereotype.Service;

@Service
public interface SimpleDatabaseService {

	public Integer countTasks() ;
}
