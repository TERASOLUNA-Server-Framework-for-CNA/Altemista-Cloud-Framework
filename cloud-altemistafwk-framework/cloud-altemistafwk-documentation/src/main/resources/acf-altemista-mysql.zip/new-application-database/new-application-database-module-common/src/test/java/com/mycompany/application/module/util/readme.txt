
Unit tests for the public utility classes of the module business module.
