/**
 * Public utility classes of the module business module.
 */
package com.mycompany.application.module.util;
