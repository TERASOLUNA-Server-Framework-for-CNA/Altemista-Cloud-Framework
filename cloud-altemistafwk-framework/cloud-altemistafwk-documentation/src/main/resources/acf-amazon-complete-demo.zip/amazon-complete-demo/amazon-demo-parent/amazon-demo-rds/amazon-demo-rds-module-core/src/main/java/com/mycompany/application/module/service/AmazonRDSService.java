package com.mycompany.application.module.service;

public interface AmazonRDSService {

	public void insertRow(String description);
}
