package com.mycompany.application.module.service;

public interface MailSenderService {

	public void sendMessage(String message) ;

}
