package com.mycompany.application.module.service;


public interface SqsQueueSender {

	public void send(String message) ;
}