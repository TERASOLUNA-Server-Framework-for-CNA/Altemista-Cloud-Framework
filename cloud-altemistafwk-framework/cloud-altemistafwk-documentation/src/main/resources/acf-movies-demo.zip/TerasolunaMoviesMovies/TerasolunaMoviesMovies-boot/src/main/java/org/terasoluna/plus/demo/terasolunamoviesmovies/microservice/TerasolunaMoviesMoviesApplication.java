package org.terasoluna.plus.demo.terasolunamoviesmovies.microservice;

import org.terasoluna.plus.config.boot.TerasolunaPlusApplicationBuilder;
import org.terasoluna.plus.config.microservice.TerasolunaPlusMicroserviceBuilder;
import org.terasoluna.plus.config.microservice.TerasolunaPlusMicroservice;

/**
 * The Class TerasolunaMoviesMoviesApplication.
 */
@TerasolunaPlusMicroservice
public class TerasolunaMoviesMoviesApplication extends TerasolunaPlusMicroserviceBuilder {

    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
        configureApplication(new TerasolunaPlusApplicationBuilder(), TerasolunaMoviesMoviesApplication.class).run(args);
    }
	
}
