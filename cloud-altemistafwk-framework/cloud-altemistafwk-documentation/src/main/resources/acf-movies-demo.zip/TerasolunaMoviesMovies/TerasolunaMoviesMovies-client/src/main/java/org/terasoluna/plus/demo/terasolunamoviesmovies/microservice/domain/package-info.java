/**
 * DTOs
 */
package org.terasoluna.plus.demo.terasolunamoviesmovies.microservice.domain;
