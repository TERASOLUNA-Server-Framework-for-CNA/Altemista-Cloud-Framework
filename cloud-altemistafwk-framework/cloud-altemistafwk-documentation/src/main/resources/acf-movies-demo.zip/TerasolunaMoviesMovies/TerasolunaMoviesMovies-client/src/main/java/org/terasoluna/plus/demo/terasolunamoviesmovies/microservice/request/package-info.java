/**
 * Request POJOs
 */
package org.terasoluna.plus.demo.terasolunamoviesmovies.microservice.request;
