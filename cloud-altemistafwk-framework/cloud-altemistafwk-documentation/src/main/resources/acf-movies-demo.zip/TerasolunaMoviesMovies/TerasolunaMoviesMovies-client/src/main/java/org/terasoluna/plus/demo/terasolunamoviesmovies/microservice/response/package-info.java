/**
 * Response POJOs
 */
package org.terasoluna.plus.demo.terasolunamoviesmovies.microservice.response;
