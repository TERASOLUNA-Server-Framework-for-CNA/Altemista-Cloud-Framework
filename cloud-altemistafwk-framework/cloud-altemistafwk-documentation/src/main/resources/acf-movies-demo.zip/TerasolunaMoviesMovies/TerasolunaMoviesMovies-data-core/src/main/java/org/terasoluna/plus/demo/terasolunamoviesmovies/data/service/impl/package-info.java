/**
 * Implementation of both the exposed and the internal services of data.
 * I.e.: {@code @Service} annotated classes
 */
package org.terasoluna.plus.demo.terasolunamoviesmovies.data.service.impl;
