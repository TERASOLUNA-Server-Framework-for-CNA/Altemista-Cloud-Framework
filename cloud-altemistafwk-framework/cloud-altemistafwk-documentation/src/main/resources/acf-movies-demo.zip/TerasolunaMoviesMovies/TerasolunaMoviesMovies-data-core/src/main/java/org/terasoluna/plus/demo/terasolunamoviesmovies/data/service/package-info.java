/**
 * Interfaces of the internal services of data.
 */
package org.terasoluna.plus.demo.terasolunamoviesmovies.data.service;
