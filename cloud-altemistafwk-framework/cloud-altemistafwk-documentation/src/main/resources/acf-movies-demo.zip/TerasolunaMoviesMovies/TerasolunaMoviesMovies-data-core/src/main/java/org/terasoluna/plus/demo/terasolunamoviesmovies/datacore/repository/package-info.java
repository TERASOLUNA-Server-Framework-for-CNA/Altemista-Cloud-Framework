/**
 * Interfaces of the Spring Data JPA repositories of datacore.
 */
package org.terasoluna.plus.demo.terasolunamoviesmovies.datacore.repository;
