
Unit tests for the private utility classes of the data business module.
