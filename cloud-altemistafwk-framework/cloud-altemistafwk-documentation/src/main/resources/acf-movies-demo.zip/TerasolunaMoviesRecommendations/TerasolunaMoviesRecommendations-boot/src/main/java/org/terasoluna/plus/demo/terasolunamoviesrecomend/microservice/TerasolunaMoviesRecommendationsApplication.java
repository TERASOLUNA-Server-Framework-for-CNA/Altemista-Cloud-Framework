package org.terasoluna.plus.demo.terasolunamoviesrecomend.microservice;

import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.terasoluna.plus.config.boot.TerasolunaPlusApplicationBuilder;
import org.terasoluna.plus.config.microservice.TerasolunaPlusMicroservice;
import org.terasoluna.plus.config.microservice.TerasolunaPlusMicroserviceBuilder;
import org.terasoluna.plus.demo.terasolunamoviesmovies.microservice.service.TerasolunaMoviesMovies;
import org.terasoluna.plus.demo.terasolunamoviesusers.microservice.service.TerasolunaMoviesUsers;

/**
 * The Class TerasolunaMoviesRecommendationsApplication.
 */
@TerasolunaPlusMicroservice
@EnableFeignClients(basePackageClasses = {TerasolunaMoviesUsers.class, TerasolunaMoviesMovies.class}) 
public class TerasolunaMoviesRecommendationsApplication extends TerasolunaPlusMicroserviceBuilder {

    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
        configureApplication(new TerasolunaPlusApplicationBuilder(), TerasolunaMoviesRecommendationsApplication.class).run(args);
    }
	
}
