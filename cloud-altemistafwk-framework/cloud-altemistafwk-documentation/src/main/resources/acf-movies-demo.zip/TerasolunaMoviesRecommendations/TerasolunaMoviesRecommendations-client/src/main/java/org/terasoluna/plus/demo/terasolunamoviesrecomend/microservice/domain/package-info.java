/**
 * DTOs
 */
package org.terasoluna.plus.demo.terasolunamoviesrecomend.microservice.domain;
