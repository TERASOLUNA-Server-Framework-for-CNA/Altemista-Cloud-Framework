/**
 * Response POJOs
 */
package org.terasoluna.plus.demo.terasolunamoviesrecomend.microservice.response;
