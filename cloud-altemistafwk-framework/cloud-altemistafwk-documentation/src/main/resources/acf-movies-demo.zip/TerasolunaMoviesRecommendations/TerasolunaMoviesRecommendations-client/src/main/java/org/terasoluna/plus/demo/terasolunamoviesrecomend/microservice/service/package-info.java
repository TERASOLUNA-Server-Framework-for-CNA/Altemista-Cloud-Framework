/**
 * Interfaces of the exposed services of ${businessShortId}.
 */
package org.terasoluna.plus.demo.terasolunamoviesrecomend.microservice.service;
