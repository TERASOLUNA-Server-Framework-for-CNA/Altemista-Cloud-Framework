/**
 * Private part of the business model of data
 * (i.e.: the model used internally by the data business module, but not externally exposed).
 */
package org.terasoluna.plus.demo.terasolunamoviesrecomend.data.model;
