/**
 * Interfaces of the internal services of data.
 */
package org.terasoluna.plus.demo.terasolunamoviesrecomend.data.service;
