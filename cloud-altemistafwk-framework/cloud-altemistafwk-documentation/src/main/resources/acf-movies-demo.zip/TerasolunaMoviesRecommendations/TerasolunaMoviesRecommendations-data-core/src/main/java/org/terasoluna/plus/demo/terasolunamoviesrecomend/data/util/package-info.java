/**
 * Private utility classes of the data business module.
 */
package org.terasoluna.plus.demo.terasolunamoviesrecomend.data.util;
