/**
 * Application-wide Spring MVC controllers, served at "/app/*".
 */
package com.mycompany.terasolunamoviesui.webapp.controller;
