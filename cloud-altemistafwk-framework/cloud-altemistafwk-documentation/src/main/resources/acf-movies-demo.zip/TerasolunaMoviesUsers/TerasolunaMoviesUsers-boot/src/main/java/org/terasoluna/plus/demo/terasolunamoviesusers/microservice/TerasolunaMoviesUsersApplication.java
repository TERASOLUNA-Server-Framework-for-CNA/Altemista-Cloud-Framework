package org.terasoluna.plus.demo.terasolunamoviesusers.microservice;

import org.terasoluna.plus.config.boot.TerasolunaPlusApplicationBuilder;
import org.terasoluna.plus.config.microservice.TerasolunaPlusMicroserviceBuilder;
import org.terasoluna.plus.config.microservice.TerasolunaPlusMicroservice;

/**
 * The Class TerasolunaMoviesUsersApplication.
 */
@TerasolunaPlusMicroservice
public class TerasolunaMoviesUsersApplication extends TerasolunaPlusMicroserviceBuilder {

    /**
     * The main method.
     *
     * @param args the arguments
     */
    public static void main(String[] args) {
        configureApplication(new TerasolunaPlusApplicationBuilder(), TerasolunaMoviesUsersApplication.class).run(args);
    }
	
}
