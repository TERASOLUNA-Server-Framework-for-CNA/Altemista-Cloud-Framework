/**
 * DTOs
 */
package org.terasoluna.plus.demo.terasolunamoviesusers.microservice.domain;
