/**
 * Request POJOs
 */
package org.terasoluna.plus.demo.terasolunamoviesusers.microservice.request;
