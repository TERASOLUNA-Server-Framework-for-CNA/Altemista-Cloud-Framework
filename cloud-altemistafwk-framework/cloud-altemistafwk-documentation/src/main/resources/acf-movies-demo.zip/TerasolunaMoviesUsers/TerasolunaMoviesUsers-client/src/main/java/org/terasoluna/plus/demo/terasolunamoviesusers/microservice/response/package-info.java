/**
 * Response POJOs
 */
package org.terasoluna.plus.demo.terasolunamoviesusers.microservice.response;
