/**
 * Interfaces of the exposed services of ${businessShortId}.
 */
package org.terasoluna.plus.demo.terasolunamoviesusers.microservice.service;
