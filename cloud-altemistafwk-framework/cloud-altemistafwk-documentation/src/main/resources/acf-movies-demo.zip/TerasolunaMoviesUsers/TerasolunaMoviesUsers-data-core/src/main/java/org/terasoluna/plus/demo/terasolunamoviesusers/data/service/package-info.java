/**
 * Interfaces of the internal services of data.
 */
package org.terasoluna.plus.demo.terasolunamoviesusers.data.service;
