/**
 * Interfaces of the Spring Data JPA repositories of datacore.
 */
package org.terasoluna.plus.demo.terasolunamoviesusers.datacore.repository;
