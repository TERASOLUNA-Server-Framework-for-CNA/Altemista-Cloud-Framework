
The default view resolver will resolve view names to Thymelaf from this folder ("/WEB-INF/templates").
I.e.: the view named "example" will render "/WEB-INF/templates/home.html"
